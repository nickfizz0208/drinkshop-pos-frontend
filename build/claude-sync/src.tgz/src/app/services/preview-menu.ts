import { Menu, Rule } from '../models/pos';

// 未登入時使用的五款虛構飲品與規則，只供介面預覽，不代表後端目前庫存或真實菜單。
// 登入成功後 AppComponent 會改用 API 資料；新增正式商品要改資料庫，不是只改這份。
export const PREVIEW_MENU: Menu = {
  products: [
    { product_id: 1, name: '經典紅茶', category: '茶類', price_m: 25, price_l: 30, price_bottle: null, hot_allowed: true },
    { product_id: 2, name: '茉香綠茶', category: '茶類', price_m: 25, price_l: 30, price_bottle: null, hot_allowed: true },
    { product_id: 3, name: '經典奶茶', category: '奶茶', price_m: 40, price_l: 50, price_bottle: null, hot_allowed: true },
    { product_id: 4, name: '珍珠奶茶', category: '奶茶', price_m: 50, price_l: 60, price_bottle: null, hot_allowed: true },
    { product_id: 5, name: '芒果冰沙', category: '冰沙', price_m: 55, price_l: 65, price_bottle: null, hot_allowed: false }
  ],
  toppings: [{ topping_id: 1, name: '珍珠', price: 10 }, { topping_id: 2, name: '茶凍', price: 10 }]
};
export const PREVIEW_RULES: Rule[] = [
  { rule_id: 1, rule_type: 'FORBID', condition_json: { temperatureIn: ['WARM', 'HOT'] }, action_json: { forbidToppingIds: [2] }, message: '溫熱飲不可加茶凍' },
  { rule_id: 2, rule_type: 'AUTO_ADJUST', condition_json: { category: '冰沙' }, action_json: { set: { temperature: 'COLD', sugar: 'NORMAL', ice: 'NORMAL' }, lockFields: ['temperature', 'sugar', 'ice'] }, message: '冰沙固定冰量與甜度' },
  { rule_id: 3, rule_type: 'AUTO_ADJUST', condition_json: { temperatureIn: ['WARM', 'HOT'] }, action_json: { set: { ice: 'NONE' }, lockFields: ['ice'] }, message: '溫熱飲不加冰塊' },
  { rule_id: 4, rule_type: 'MAX_COUNT', condition_json: { always: true }, action_json: { field: 'toppingIds', maxDistinct: 3 }, message: '額外加料最多三種' }
];
